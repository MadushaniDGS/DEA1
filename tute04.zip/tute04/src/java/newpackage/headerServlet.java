/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Madushani
 */
@WebServlet(name = "headerServlet", urlPatterns = {"/headerServlet"})
public class headerServlet extends HttpServlet {

   
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        PrintWriter out = response.getWriter();
        
        
       out.println("<html>");
       out.println("<head>");
       out.println("<title>Headers</title>");
       out.println("</head>");
       out.println("<body>");
       out.println("<table border ='1'>");
       out.println("<tr bgcolor ='#c3c3c3'><th>Header</th><th>value</th></tr>");
       
        
        
        
        Enumeration<String> headerNames = request.getHeaderNames();
        while(headerNames.hasMoreElements()){
            String headerName = headerNames.nextElement();
            String headerValue = request.getHeader(headerName);
            out.println("<tr><td>" +headerName+ "</td><td>" +headerValue+" </td></tr>");
        }
        
        
        out.println("<table>");
        out.println("<body>");
        out.println("<html>");
        
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        
        doGet(request,response);
    
    }

   

}
